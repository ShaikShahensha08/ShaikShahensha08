﻿using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class RatingRepository : Repository<TblRating>, IRatingRepository
    {
        public RatingRepository(RestaurantManagementContext context) : base(context) { }

        public IQueryable<TblRating> GetRestaurantRating(int restaurantID)
        {
            try
            {
                if (_context != null)
                {
                    return (from rating in _context.TblRating
                            join restaurant in _context.TblRestaurant on
                            rating.TblRestaurantId equals restaurant.Id
                            where rating.TblRestaurantId == restaurantID
                            select new TblRating
                            {
                                Rating = rating.Rating,
                                Comments = rating.Comments,
                                TblRestaurant = restaurant,
                            }).AsQueryable();
                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
