﻿using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class CuisineRepository : Repository<TblCuisine>, ICuisineRepository
    {
        public CuisineRepository(RestaurantManagementContext context) : base(context) { }
    }
}
