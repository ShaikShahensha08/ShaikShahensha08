﻿using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class RestaurantDetailRepository : Repository<TblRestaurantDetails>, IRestaurantDetailRepository
    {
        public RestaurantDetailRepository(RestaurantManagementContext context) : base(context) { }

        public IQueryable<TblRestaurantDetails> GetTableDetails(int restaurantID)
        {
            try
            {
                if (_context != null)
                {
                    return (from restaurantDetails in _context.TblRestaurantDetails
                            join restaurant in _context.TblRestaurant
                            on restaurantDetails.TblRestaurantId equals restaurant.Id
                            where restaurantDetails.TblRestaurantId == restaurantID
                            select new TblRestaurantDetails
                            {
                                TableCapacity = restaurantDetails.TableCapacity,
                                TableCount = restaurantDetails.TableCount,
                                TblRestaurant = restaurant
                            }).AsQueryable();

                }
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
