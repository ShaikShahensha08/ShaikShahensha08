﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository.Interface
{
    public interface IUnitofWork : IDisposable
    {
        IRestaurantRepository RestaurantRepository { get; }
        IRestaurantDetailRepository RestaurantDetailRepository { get; }
        IRatingRepository RatingRepository { get; }
        IOfferRepository OfferRepository { get; }
        IMenuRepository MenuRepository { get; }
        ILocationRepository LocationRepository { get; }
        ICuisineRepository CuisineRepository { get; }
        ILoggingRepository LoggingRepository { get; }
        int Complete();
    }
}
