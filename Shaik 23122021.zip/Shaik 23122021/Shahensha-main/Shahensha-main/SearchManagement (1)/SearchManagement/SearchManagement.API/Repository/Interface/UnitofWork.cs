﻿using SearchManagement.API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository.Interface
{
    public class UnitofWork : IUnitofWork
    {
        private readonly RestaurantManagementContext _context;

        public UnitofWork(RestaurantManagementContext context)
        {
            _context = context;
            RestaurantRepository = new RestaurantRepository(_context);
            RestaurantDetailRepository = new RestaurantDetailRepository(_context);
            RatingRepository = new RatingRepository(_context);
            OfferRepository = new OfferRepository(_context);
            MenuRepository = new MenuRepository(_context);
            LocationRepository = new LocationRepository(_context);
            CuisineRepository = new CuisineRepository(_context);
            LoggingRepository = new LoggingRepository(_context);

        }
        public IRestaurantRepository RestaurantRepository { get; private set; }

        public IRestaurantDetailRepository RestaurantDetailRepository { get; private set; }

        public IRatingRepository RatingRepository { get; private set; }

        public IOfferRepository OfferRepository { get; private set; }

        public IMenuRepository MenuRepository { get; private set; }

        public ILocationRepository LocationRepository { get; private set; }

        public ICuisineRepository CuisineRepository { get; private set; }

        public ILoggingRepository LoggingRepository { get; private set; }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
