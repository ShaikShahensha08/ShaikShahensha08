﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Models
{
    public class LocationDetails
    {
        public string restaurant_Name { get; set; }
        public double xaxis { get; set; }
        public double yaxis { get; set; }
        public double distance { get; set; }
    }
}
