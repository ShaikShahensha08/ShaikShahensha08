﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Models
{
    public class StockItems
    {
        public int RestaurantID { get; set; }
        public int Quantity { get; set; }
    }
}
